package posApp;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class StockWindow extends JFrame implements ActionListener{

	JLabel labelId = new JLabel("ID");
	JLabel labelName = new JLabel("��ǰ��");
	JLabel labelStock = new JLabel("�����");
	JLabel labelPrice = new JLabel("����");
	
	JTextField textFieldID = new JTextField();
	JTextField textFieldName = new JTextField();
	JTextField textFieldStock = new JTextField();
	JTextField textFieldPrice = new JTextField();
	
	JButton buttonAccept = new JButton("");
	Item item = new Item();
	String text;
	
	public StockWindow(String text) {
		this.text = text;
		display();
		setSize(300,300);
		setVisible(true);
	}
	
	public StockWindow(String text, Item item) {
		this.text = text;
		display();
		setSize(300,300);
		setVisible(true);
	}
	
	public void display() {
		Container c = getContentPane();
		JPanel p = new JPanel(new GridLayout(4,2));
		buttonAccept.setText(text);
		textFieldID.setEditable(false);
		
		if(item!=null) {
			textFieldID.setText(Integer.toString(item.getId()));
			textFieldName.setText(item.getItem_name());
			textFieldStock.setText(Integer.toString(item.getItem_stock()));
			textFieldPrice.setText(Integer.toString(item.getItem_price()));
		}
		
		p.add(labelId);
		p.add(textFieldID);
		
		p.add(labelName);
		p.add(textFieldName);
		
		p.add(labelStock);
		p.add(textFieldStock);
		
		p.add(labelPrice);
		p.add(textFieldPrice);
		
		c.add(p, BorderLayout.CENTER);
		c.add(buttonAccept, BorderLayout.SOUTH);
		
		buttonAccept.addActionListener(this);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		String state = buttonAccept.getText();
		String id;
		String name;
		String stock;
		String price;
		boolean result = false;
		
		switch(state) {
			case "���":
				name = textFieldName.getText();
				stock = textFieldStock.getText();
				price = textFieldPrice.getText();
				
				Item register = new Item();
				register.setItem_name(name);
				register.setItem_stock(Integer.parseInt(stock));
				register.setItem_price(Integer.parseInt(price));
				
				try {
					result = ItemDAO.getInstance().insertStock(register);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			
			case "����":
				id = textFieldID.getText();
				name = textFieldName.getText();
				stock = textFieldStock.getText();
				price = textFieldPrice.getText();
				
				item.setId(Integer.parseInt(id));
				item.setItem_name(name);
				item.setItem_stock(Integer.parseInt(stock));
				item.setItem_price(Integer.parseInt(price));				
				
				try {
					result = ItemDAO.getInstance().updateStock(item);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			
				if(result) {
					JOptionPane.showMessageDialog(null, "���� ����!", "����!", JOptionPane.INFORMATION_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(null, "���� ����!", "����!", JOptionPane.WARNING_MESSAGE);
				}
				break;
				
		case "����":
			id = textFieldID.getText();
			name = textFieldName.getText();
			stock = textFieldStock.getText();
			price = textFieldPrice.getText();
			
			item.setId(Integer.parseInt(id));
			item.setItem_name(name);
			item.setItem_stock(Integer.parseInt(stock));
			item.setItem_price(Integer.parseInt(price));				
			
			int res;
			res = JOptionPane.showConfirmDialog(null, "������ ��ǰ�� " + name+"�� DB���� �����Ͻðڽ��ϱ�?");
			
			if(res==0) {
				try {
					result = ItemDAO.getInstance().deleteItem(Integer.parseInt(id));
					dispose();
					JOptionPane.showMessageDialog(null, "�����Ϸ��� " + name + "�� �����߽��ϴ�");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}else {
				JOptionPane.showMessageDialog(null, "������ ����߽��ϴ�");
			}
			
			break;		
		}
	}	
}
