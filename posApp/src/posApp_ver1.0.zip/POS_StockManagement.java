package posApp;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class POS_StockManagement extends JPanel implements ActionListener{
	
	private JLabel labelName;
	private JTable jtableStock;
	private JButton buttonDB;
	private JButton buttonRegister;
	private JButton buttonUpdate;
	private JButton buttonDelete;
	
	public POS_StockManagement() {
		
		setLayout(null);
		
		labelName = new JLabel("�����Ȳ");
		labelName.setSize(100,40);
		labelName.setLocation(60,20);
		
		DefaultTableModel model = new DefaultTableModel();
		
//		TableColumnModel columnModel = new DefaultTableColumnModel();
//		TableCellRenderer defaultRenderer = new DefaultTableCellRenderer();
//		TableColumn column = new TableColumn(0);
//		column.setCellRenderer(defaultRenderer);
//		column.setHeaderValue("id");
//		columnModel.addColumn(column);
//		column = new TableColumn(1);
//		column.setHeaderValue("��ǰ��");
//		columnModel.addColumn(column);
//		column = new TableColumn(2);
//		column.setHeaderValue("�����");
//		columnModel.addColumn(column);
//		column = new TableColumn(3);
//		column.setHeaderValue("��ǰ����");
//		columnModel.addColumn(column);
		
		model.addColumn("id");
		model.addColumn("��ǰ��");
		model.addColumn("�����");
		model.addColumn("��ǰ����");
		
		jtableStock = new JTable(model);
		jtableStock.setBounds(200,20,300,280);		
		
		buttonDB = new JButton("��ǰ ���ΰ�ħ");
		buttonDB.setBounds(10,70,150,40);
		
		buttonRegister = new JButton("���");
		buttonRegister.setBounds(10,130,150,40);
		
		buttonUpdate = new JButton("����");
		buttonUpdate.setBounds(10,190,150,40);
		
		buttonDelete = new JButton("����");
		buttonDelete.setBounds(10,250,150,40);
		
		add(labelName);
		add(jtableStock);
		add(buttonDB);
		add(buttonRegister);
		add(buttonUpdate);
		add(buttonDelete);
		
		buttonDB.addActionListener(this);
		buttonRegister.addActionListener(this);
		buttonUpdate.addActionListener(this);
		buttonDelete.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		Object obj = e.getSource();
		
		DefaultTableModel model = (DefaultTableModel)jtableStock.getModel();
		
		try {
			if(obj==buttonDB) {
				loadDB(model);
			}else if(obj==buttonRegister) {
				String text = buttonRegister.getText();
				StockWindow window = new StockWindow(text);
			}else if(obj==buttonUpdate) {
				int row  = jtableStock.getSelectedRow();
				if(row==-1) {
					JOptionPane.showMessageDialog(null, "���� �������ּ���", "���!", JOptionPane.WARNING_MESSAGE);					
				}else {
					String text = buttonUpdate.getText();
					String id = (String)jtableStock.getValueAt(row, 0);
					String name = (String)jtableStock.getValueAt(row, 1);
					String stock = (String)jtableStock.getValueAt(row, 2);
					String price = (String)jtableStock.getValueAt(row, 3);
					
					Item item = new Item();
					item.setId(Integer.parseInt(id));
					item.setItem_name(name);
					item.setItem_stock(Integer.parseInt(stock));
					item.setItem_price(Integer.parseInt(price));
					
					StockWindow window = new StockWindow(text, item);
				}
			}else if(obj==buttonDelete) {
				int row  = jtableStock.getSelectedRow();
				if(row==-1) {
					JOptionPane.showMessageDialog(null, "���� �������ּ���", "���!", JOptionPane.WARNING_MESSAGE);					
				}else {
					String text = buttonUpdate.getText();
					String id = (String)jtableStock.getValueAt(row, 0);
					String name = (String)jtableStock.getValueAt(row, 1);
					String stock = (String)jtableStock.getValueAt(row, 2);
					String price = (String)jtableStock.getValueAt(row, 3);
					
					Item item = new Item();
					item.setId(Integer.parseInt(id));
					item.setItem_name(name);
					item.setItem_stock(Integer.parseInt(stock));
					item.setItem_price(Integer.parseInt(price));
					
					StockWindow window = new StockWindow(text, item);
				}
			}
		}catch(Exception ae) {
			ae.printStackTrace();
		}
	}
	
	private void loadDB(DefaultTableModel model) throws Exception {
		
		int rows = model.getRowCount();
		
		for(int i=rows-1; i>=0; i--)
			model.removeRow(i);
		
		Vector<Item> itemlist = ItemDAO.getInstance().getAllItem();
		
		for(Item item: itemlist) {
			String item_id = Integer.toString(item.getId());
			String item_name = item.getItem_name();
			String item_stock = Integer.toString(item.getItem_stock());
			String item_price = Integer.toString(item.getItem_price());
			
			Vector<String> in = new Vector<String>();
			in.add(item_id);
			in.add(item_name);
			in.add(item_stock);
			in.add(item_price);
			model.addRow(in);
		}		
	}
}
